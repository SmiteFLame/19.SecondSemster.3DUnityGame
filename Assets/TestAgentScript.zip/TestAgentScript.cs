﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class TestAgentScript : MonoBehaviour
{
    public Transform Target;
    NavMeshAgent agent;
    int randomNuber;
    bool isSearch = false;
    private Animator anim;
    public int hashAttack = Animator.StringToHash("isAttack");
    public bool check=true;

    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        randomNuber = Random.Range(1, 5);
        anim = GetComponent<Animator>();
        if (randomNuber > 2)
        {
            Target = GameObject.FindWithTag("Player").GetComponent<Transform>();
        }
        else
        {
            Target = GameObject.FindWithTag("Castle").GetComponent<Transform>();

        }
    }

    // Update is called once per frame
    void Update()
    {
        agent.SetDestination(Target.position);
        if (isSearch == true&&check)
        { //기존과 탐색 조건을 추가함
            
            StartCoroutine(Attack()); //공격기능			

        }
        Search();
    }

    void Search()
    {

        float distance = Vector3.Distance(Target.transform.position, transform.position);
        if (distance <= 3)
        {
            Debug.Log("할 수 있다.");
           isSearch = true;
        }
    }

    IEnumerator Attack()
    {
        check = false;
        
        //anim.SetBool(hashAttack, true);
        anim.SetTrigger(hashAttack);
        //돌아보는 방향을 플레이어 쪽으로
        yield return new WaitForSeconds(1.5f);
       
        check = true;
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(Target.transform.position - transform.position), Time.smoothDeltaTime * 5.0f);
        Debug.Log(this.gameObject);
        float distance = Vector3.Distance(Target.transform.position, transform.position);
        //anim.SetBool(hashAttack, false);

        //거리가 멀어지면 탐색 실패

        if (distance > 3)
        {
            isSearch = false;
        }
    }
}
